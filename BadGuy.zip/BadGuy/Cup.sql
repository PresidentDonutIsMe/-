SET NAMES 'utf8mb4';
DROP DATABASE IF EXISTS Cup;
CREATE DATABASE Cup CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE Cup;

DROP TABLE IF EXISTS Product;
CREATE TABLE Product (
	pro_id VARCHAR(20) NOT NULL UNIQUE,
    pro_name VARCHAR(100) NOT NULL,
    pro_category VARCHAR(10) NOT NULL,
    pro_brand_name VARCHAR(20) NOT NULL,
    pro_material VARCHAR(20) NOT NULL,
    pro_hot VARCHAR(20) NOT NULL,
	pro_volume varchar(10) NOT NULL,
    pro_detail VARCHAR(100) NOT NULL,
    pro_price varchar(10),
	pro_img1 VARCHAR(100), 
    pro_img2 VARCHAR(100),
    pro_note VARCHAR(100) NOT NULL,
    pro_amount varchar(10),
    pro_sales int,
    PRIMARY KEY (pro_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
ALTER TABLE Product CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
INSERT INTO Product VALUES ('1','Tonton不銹鋼杯-極簡白','飲料杯','holoholo','316不鏽鋼',' 0°C～100°C','450ml','雙層不鏽鋼，保溫效能up up，可耐酸，各式飲品皆可裝','759','drinkcup/drinkcup1.png','drinkcup1_2.png','杯身','100','1002');
INSERT INTO Product VALUES ('2','Tonton吸管杯-極簡白','飲料杯','holoholo','Tritan','0°C～96°C','450ml','一杯兩用，可直飲or吸管飲用，完美矽膠密封，不怕溢漏','559','drinkcup/drinkcup2.png','drinkcup2_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('3','Tonton吸管杯-西瓜綠','飲料杯','holoholo','Tritan','0°C～96°C','450ml','一杯兩用，可直飲or吸管飲用，完美矽膠密封，不怕溢漏','559','drinkcup/drinkcup3.png','drinkcup3_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('4','大象杯-檸檬派','飲料杯','elephantcuppa','Ecozen','0°C～90°C','520ml','一款可以滿足各種需求的飲料杯。容量大、防漏、寬口直徑容易清洗，方便你每天帶出門！','759','drinkcup/drinkcup4.png','drinkcup4_2.png','Ecozen 飲料杯、Ecozen粗吸管 & 細吸管、清洗毛刷','100','1000');
INSERT INTO Product VALUES ('5','大象杯-莫蘭迪綠','飲料杯','elephantcuppa','Ecozen','0°C～90°C','520ml','一款可以滿足各種需求的飲料杯。容量大、防漏、寬口直徑容易清洗，方便你每天帶出門！','759','drinkcup/drinkcup5.png','drinkcup5_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('6','大象杯-經典黑','飲料杯','elephantcuppa','Ecozen','0°C～90°C','720ml','一款可以滿足各種需求的飲料杯。容量大、防漏、寬口直徑容易清洗，方便你每天帶出門！','759','drinkcup/drinkcup6.png','drinkcup6_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('7','FLOAT 漂浮珍奶杯','飲料杯','FLOAT','Tritan',' -40°C～100°C','850ml','全球首款唔洗吸管都飲到珍珠的「FLOAT 漂浮珍奶杯」。無左吸管，飲料杯變得更易清洗、更好攜帶、甚至更方便飲用。','930','drinkcup/drinkcup7.png','drinkcup7_2.png','杯身、內杯、杯蓋','100','1000');
INSERT INTO Product VALUES ('8','UFO磁浮杯-祖母綠','飲料杯','deercheer新創','Tritan','0°C～96°C','1380ml','利用特殊磁力結構，使磁浮島可以自由上下移動於瓶中撈配料，讓茶葉、珍珠、果片不宜長期浸泡在飲品中的食材能得到喘息的空間，維持絕佳的茶飲風味，讓每一口都像第一口。','700ml','drinkcup/drinkcup8.png','drinkcup8_2.png','杯身、公仔','100','1000');
INSERT INTO Product VALUES ('9','Jelly Mini 果凍隨行-奶油白','隨行杯','holoholo','316不鏽鋼',' 0°C～100°C','200ml','小巧果凍造型質感霧面保溫杯，可愛果凍外型，迷你小巧好攜帶','659','tumbler/tumbler7.png','tumbler7_2.png','杯身','100','999');
INSERT INTO Product VALUES ('10','Jelly Mini 果凍隨行-淺紫','隨行杯','holoholo','316不鏽鋼',' 0°C～100°C','200ml','小巧果凍造型質感霧面保溫杯，可愛果凍外型，迷你小巧好攜帶','659','tumbler/tumbler1.png','tumbler1_2.png','杯身','100','1002');
INSERT INTO Product VALUES ('11','HIDING iN隨行杯-太空灰','隨行杯','HIDING iN','304不鏽鋼','  0°C～60°C','750ml','業界唯一專利，一體成形的曲面內膽，傾斜就能集中料物，一滴不剩喝乾淨','1080','tumbler/tumbler2.jpeg','tumbler2_2.jpeg','飲料杯、專用Tritan粗吸管 / 細吸管','100','1000');
INSERT INTO Product VALUES ('12','HIDING iN隨行杯-隕石黑','隨行杯','HIDING iN','304不鏽鋼','  0°C～60°C','750ml','業界唯一專利，一體成形的曲面內膽，傾斜就能集中料物，一滴不剩喝乾淨','1080','tumbler/tumbler3.jpeg','tumbler3_2.jpeg','飲料杯、專用Tritan粗吸管 / 細吸管','100','1000');
INSERT INTO Product VALUES ('13','微笑騎士隨行杯-米綠','隨行杯','LockLock','304不鏽鋼',' -20°C~100°C','540ml','提環設計隨時隨地方便攜帶，直飲上蓋，易於直飲的設計','1089','tumbler/tumbler4.png','tumbler4_2.png','杯身、吸管','100','1000');
INSERT INTO Product VALUES ('14','微笑騎士隨行杯-焦糖奶茶','隨行杯','LockLock','304不鏽鋼',' -20°C~100°C','540ml','提環設計隨時隨地方便攜帶，直飲上蓋，易於直飲的設計','1089','tumbler/tumbler5.png','tumbler5_2.png','杯身、吸管','100','1000');
INSERT INTO Product VALUES ('15','微笑騎士隨行杯-英倫藍','隨行杯','LockLock','304不鏽鋼',' -20°C~100°C','540ml','提環設計隨時隨地方便攜帶，直飲上蓋，易於直飲的設計','1089','tumbler/tumbler6.png','tumbler6_2.png','杯身、吸管','100','1000');
INSERT INTO Product VALUES ('16','小莊園系列隨行杯-茶花之丘','隨行杯','oolab','304不鏽鋼','  0°C～80°C','710ml','結合不鏽鋼與陶瓷，比白瓷更輕盈。還有附贈防漏杯塞，走到哪，帶到哪。','1200','tumbler/tumbler8.png','tumbler8_2.png','杯身、吸管、防漏塞','100','999');
INSERT INTO Product VALUES ('17','標準口提環保溫瓶-浪花白','保溫杯','Hydro Flask','18/8級不銹鋼',' 0°C～100°C','621ml','保冷最高達24小時，保溫達12小時，獲得德國紅點設計大獎','1300','thermos/thermos1.png','thermos1_1.png','杯身','100','1002');
INSERT INTO Product VALUES ('18','標準口酒瓶 迷霧紫','保溫杯','Hydro Flask','18/8級不銹鋼',' 0°C～100°C','749ml','保冷最高達24小時，保溫達12小時，獲得德國紅點設計大獎','1680','thermos/thermos2.png','thermos2_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('19','白瓶-雲灰','保溫杯','HYDY','18/8級不銹鋼',' 0°C～100°C','590ml','兼具時尚以及實用的設計，雙層杯口設計，避免水大量流出。底層馬卡龍色系矽膠套，保護家具防止刮傷、防滑、好拿取。','1390','thermos/thermos3.png','thermos3_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('20','保溫壺露營桶-冷杉','保溫杯','HYDY','18/8級不銹鋼',' 0°C～100°C','1920ml','超大容量，多人戶外出遊最佳配備，提把設計，輕鬆好持。','2980','thermos/thermos4.png','thermos4_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('21','不鏽鋼真空保溫水樽-海軍藍','保溫杯','CamelBak','18/8級不銹鋼',' 0°C～100°C','1000ml','新一代磁性樽蓋，可吸附在側面，實現單手飲水，防漏瓶蓋設計，讓飲品不溢漏。','1200','thermos/thermos5.png','thermos5_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('22','不鏽鋼真空保溫水樽-湖水綠','保溫杯','CamelBak','18/8級不銹鋼',' 0°C～100°C','1000ml','新一代磁性樽蓋，可吸附在側面，實現單手飲水，防漏瓶蓋設計，讓飲品不溢漏。','1200','thermos/thermos6.png','thermos6_2.png','杯身','100','1000');
INSERT INTO Product VALUES ('23','Woky隨行陶瓷保溫瓶-粉','保溫杯','woky','陶瓷內膽+304不鏽鋼+PP蓋子',' 0°C～100°C','260ml','業界最輕的陶瓷保溫杯，輕量工藝，結合時尚，輕巧隨行。','1200','thermos/thermos7.png','thermos7_2.png','杯身、濾網','100','1000');
INSERT INTO Product VALUES ('24','Woky手提輕芯鈦瓷保溫杯-白','保溫杯','woky','不鏽鋼+鈦陶瓷塗層',' 0°C～100°C','750ml','鈦陶瓷塗層好清潔不易殘留異味，安全無毒好安心。','1480','thermos/thermos8.png','thermos8_2.png','杯身','100','999');

CREATE TABLE Member_List (
    Mem_ID INT AUTO_INCREMENT,
    Mem_Account VARCHAR(20) NOT NULL UNIQUE,
    Mem_Password VARCHAR(20) NOT NULL,
    Mem_Identity varchar(10),
    Mem_Photo varchar(40),
    Mem_Name VARCHAR(10),
    Mem_Gender VARCHAR(10) default "男",
    Mem_Age INTEGER,
    Mem_Birth DATE,
    Mem_Tele VARCHAR(15),
    Mem_Email VARCHAR(60) NOT NULL,
    Mem_Address VARCHAR(60),
    PRIMARY KEY (Mem_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

CREATE TABLE `messages` (
  `ID` int(11) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `score` int(3) NOT NULL,
  `product_id` int(11) NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
ALTER TABLE `messages`
  ADD PRIMARY KEY (`ID`);
  ALTER TABLE `messages`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

drop table if exists Orders_Detail;
CREATE TABLE Orders_Detail(
  pro_id VARCHAR(20) NOT NULL UNIQUE,
  Mem_Account VARCHAR(20) NOT NULL UNIQUE,
  Pur_Quantity VARCHAR(10),
  statue varchar(10),
  PRIMARY KEY (pro_id),
  FOREIGN KEY (pro_id) REFERENCES Product (pro_id)
) ;
alter table Orders_Detail add FOREIGN KEY (pro_id) REFERENCES Product(pro_id);

CREATE TABLE Orders(
  order_id int NOT NULL AUTO_INCREMENT,
  pro_id VARCHAR(20) NOT NULL,
  Mem_Account VARCHAR(20) NOT NULL,
  Mem_Tele VARCHAR(15),
  Date_Purchase varchar(45),
  Pur_Quantity VARCHAR(10),
  total VARCHAR(10),
  ship VARCHAR(10),
  payway VARCHAR(10),
  PRIMARY KEY (order_id),
  FOREIGN KEY (pro_id) REFERENCES Product (pro_id)
) ;

CREATE TABLE `randad` (
  `ADID` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `file_path` varchar(20) NOT NULL,
  `ad_file` varchar(20) NOT NULL,
  `link` varchar(30) NOT NULL,
  `Alternate` text NOT NULL,
  `ADContent` text NOT NULL,
  PRIMARY KEY (`ADID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- ----------------------------
-- Records of randad
-- ----------------------------
INSERT INTO randad VALUES ('1', 'images', '01.gif', 'shopping.pchome.com.tw', 'pchome網路購物', 'pchome網路購物');
INSERT INTO randad VALUES ('2', 'images', '02.gif', 'tw.yahoo.com', 'yahoo', 'yahoo');
INSERT INTO randad VALUES ('3', 'images', '03.gif', 'udn.com', '聯合新聞網', '聯合新聞網');

CREATE TABLE counter(
  counter Int UNIQUE,
  PRIMARY KEY (counter)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

Insert into counter Values (0)